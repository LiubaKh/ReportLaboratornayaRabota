INSERT INTO product (name, brand, price, quantity) VALUES ( 'Молоко', 'Домик в деревне', 41, 10);
INSERT INTO product (name, brand, price, quantity) VALUES ( 'Йогурт', 'Valio', 34, 6);
INSERT INTO product (name, brand, price, quantity) VALUES ( 'Пельмени', 'Сытоедов', 120, 2);
INSERT INTO product (name, brand, price, quantity) VALUES ( 'Хлебцы', 'Dr. Corner', 60, 30);
INSERT INTO product (name, brand, price, quantity) VALUES ( 'Вода', 'Evian', 100, 60);